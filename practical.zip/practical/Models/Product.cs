﻿using System;
using System.Collections.Generic;

namespace practical;

public partial class Product
{
    public int ProdId { get; set; }

    public string? ProdName { get; set; }

    public int? ProdPrice { get; set; }

    public string? ProdDesc { get; set; }

    public virtual ICollection<Orderr> Orderrs { get; set; } = new List<Orderr>();

    public virtual ICollection<ShoppingCart> ShoppingCarts { get; set; } = new List<ShoppingCart>();
}
