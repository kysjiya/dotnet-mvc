﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using practical.Models;

namespace practical.Controllers;

public class HomeController : Controller
{
     private readonly AssignmentContext _context;

    public HomeController(AssignmentContext context)
    {
        _context = context;
    }

    public IActionResult Index()
    {
    
       ViewBag.query = from product in _context.Products 
        join order in _context.Orderrs on product.ProdId equals order.ProductId
        select new { Quantity = order.Quantity, Name = product.ProdName, Price = product.ProdPrice, Total = order.Total, Date = order.OrderDate};
        return View();

    
    }
    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
